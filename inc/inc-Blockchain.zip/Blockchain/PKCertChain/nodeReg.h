#pragma once
#include <cstdint>

// Placeholder struct for node registration / block
struct nodeReg {
    uint32_t nodeId;
    // Add other fields as necessary
};
